var aa = getApp();
String.prototype.endWith=function(str){
  if(str==null||str==""||this.length==0||str.length>this.length)
    return false;
  if(this.substring(this.length-str.length)==str)
    return true;
  else
    return false;
  return true;
}
String.prototype.startWith=function(str){     
  var reg=new RegExp("^"+str);     
  return reg.test(this);        
}  
var flags=new Array();
var frag=[];
var tempFrag1=[],tempFrag2=[],tempFrag3=[],tempFrag4=[],tempFrag5=[],tempFrag6=[];
function getFlagArrar(txt){
  if(txt!=null&&txt.indexOf("_img_end_") > 0){
      tempFrag1=txt.split("_img_end_");
      for(var i=0;i<tempFrag1.length;i++){
           getFlagArrar(tempFrag1[i]);
      }
  }else if(txt!=null&&txt.indexOf("_video_end_") > 0){
      tempFrag2=txt.split("_video_end_");
      for(var i=0;i<tempFrag2.length;i++){
          getFlagArrar(tempFrag2[i]);
      }
  }else if(txt!=null&&txt.indexOf("_img_start_") > 0){
         //console.log("_img_start_->"+txt);
         tempFrag3=txt.split("_img_start_");
         for(var i=0;i<tempFrag3.length;i++){
            getFlagArrar(tempFrag3[i]);
         }
  }else if(txt!=null&&txt.indexOf("_video_start_") > 0){
         //console.log("_video_start_->"+txt);
         tempFrag4=txt.split("_video_start_");
         for(var i=0;i<tempFrag4.length;i++){
            getFlagArrar(tempFrag4[i]);
         }
  }else if(txt!=null&&txt.endWith(".mp4")){
        if(txt!=null&&txt.startWith("_video_start_")){
           tempFrag6=txt.split("_video_start_");
           for(var i=0;i<tempFrag6.length;i++){
               getFlagArrar(tempFrag6[i]);
           }
         }else{
            frag=[txt,3];
            flags.push(frag);
         }
  }else if(txt!=null&&(txt.endWith(".bmp")||txt.endWith(".jpg")||txt.endWith(".jpeg")||txt.endWith(".gif")||txt.endWith(".png"))){
         if(txt!=null&&txt.startWith("_img_start_")){
           tempFrag5=txt.split("_img_start_");
           for(var i=0;i<tempFrag5.length;i++){
               getFlagArrar(tempFrag5[i]);
           }
         }else{
            frag=[txt,2];
            flags.push(frag);
         }
  }else{
     //1正文类型  2图片  3视频
     frag=[txt,1];
     flags.push(frag);
  }
}
Page({
  data:{
      content:'',
      contentFrag:[][1]
  },
  onLoad:function(options){
      aa.showModel();
      var self=this;
      wx.request({
        url: 'https://demo.jeecms.com/api/content/get.jspx',
        data: {
          https:0,
          format:1,
          id:options.id
        },
        header: {
          'content-type': 'application/json'
        },
        dataType:'json',
        method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        success: function(res){
          flags=[];
         // console.log("options.id->"+options.id);
         // console.log(res.data);
         // console.log("flags.length->"+flags.length);
          getFlagArrar(res.data.txt);
          self.setData({
            content:res.data,
            flags:flags
          })
           wx.hideToast();
        }
      })
  }
})